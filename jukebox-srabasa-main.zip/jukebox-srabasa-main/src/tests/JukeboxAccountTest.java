package tests;



import org.junit.jupiter.api.Test;

import model.JukeboxAccount;

class JukeboxAccountTest {

  @Test
  void testGetters() {
    JukeboxAccount aJBA = new JukeboxAccount("Name");
  }

}
