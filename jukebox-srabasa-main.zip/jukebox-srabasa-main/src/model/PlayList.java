package model;

public class PlayList {

  public void queueUpNextSong(String songToAdd) {
     System.out.println("TODO: Implement PlayList");
  }

}